from django.shortcuts import render
def First_Action(request):
    return render(request,"welcome.html")

def Second_Action(request):
    return render(request,"profile.html",{'name':'Sandeep Sappal','city':'Gwalior','state':'Madhya Pradesh'})
    

