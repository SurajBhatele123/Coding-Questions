from django.shortcuts import render
import pymysql as sql
def EmployeeInterface(request):
    return render(request,'EmployeeInterface.html')

