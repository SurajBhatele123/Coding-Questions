from django.shortcuts import render
import pymysql as sql
def EmployeeInterface(request):
    return render(request,'EmployeeInterface.html')

def SubmitRecord(request):
    try:
        firstname=request.GET['firstname']
        lastname=request.GET['lastname']
        address=request.GET['address']
        state=request.GET['state']
        city=request.GET['city']
        dob=request.GET['dob']
        salary=request.GET['salary']
        conn=sql.connect(host="localhost",port=3306,database='django_connectivity',user='root',passwd='123')
        cmd=conn.cursor()
        query="insert into employee(employeename,address,state,city,birthdate,salary) values('{0}','{1}','{2}','{3}','{4}',{5})".format((firstname+" "+lastname),address,state,city,dob,salary)
        
        cmd.execute(query)
        conn.commit()
        conn.close()

        return render(request,'EmployeeInterface.html',{'msg':'Record Submitted Successfully'})
    except Exception as e:
        print("Errrrrrr:",e)
        return render(request,'EmployeeInterface.html',{'msg':'Fail to  Submit Record'})
def DisplayAll_Employee(request):
    try:
           conn=sql.connect(host="localhost",port=3306,database='django_connectivity',user='root',passwd='123',cursorclass=sql.cursors.DictCursor)
           cmd=conn.cursor()
           query="select * from employee"
           cmd.execute(query)
           records=cmd.fetchall()
           print(records)
           conn.close()

           return render(request,'DisplayAll.html',{'records':records})
    except Exception as e:
        print("Errrrrrr:",e)
        return render(request,'DisplayAll.html',{'msg':'Fail to  Fetch Record'})

def Display_By_Id(request):
    try:
           employeeid=request.GET['eid']
           conn=sql.connect(host="localhost",port=3306,database='django_connectivity',user='root',passwd='123',cursorclass=sql.cursors.DictCursor)
           cmd=conn.cursor()
           query="select * from employee where employeeid={0}".format(employeeid)
           cmd.execute(query)
           records=cmd.fetchone()
           name=records['employeename'].split(' ')
           print(records)
           conn.close()

           return render(request,'DisplayById.html',{'records':records,'name':name})
    except Exception as e:
        print("Errrrrrr:",e)
        return render(request,'DisplayById.html',{'msg':'Fail to  Fetch Record'})   

def Edit_Delete_Record(request):
    try:
        btn=request.GET['btn']
        employeeid=request.GET['employeeid']
        firstname=request.GET['firstname']
        lastname=request.GET['lastname']
        address=request.GET['address']
        state=request.GET['state']
        city=request.GET['city']
        dob=request.GET['dob']
        salary=request.GET['salary']
        conn=sql.connect(host="localhost",port=3306,database='django_connectivity',user='root',passwd='123')
        cmd=conn.cursor()

        if(btn=="Delete"):
         query="delete from employee where employeeid={0}".format(employeeid)
         cmd.execute(query)
        else:
          query="update employee set employeename='{0}', address='{1}',state='{2}',city='{3}',birthdate='{4}', salary={5}  where employeeid={6}".format((firstname+" "+lastname),address,state,city,dob,salary,employeeid)
          cmd.execute(query)
             
        conn.commit()
        conn.close()

        return DisplayAll_Employee(request)
    except Exception as e:
        print("Errrrrrr:",e)
        return DisplayAll_Employee(request)


