from django.shortcuts import render
import pymysql as sql
def EmployeeInterface(request):
    return render(request,'EmployeeInterface.html')

def SubmitRecord(request):
    try:
        firstname=request.GET['firstname']
        lastname=request.GET['lastname']
        address=request.GET['address']
        state=request.GET['state']
        city=request.GET['city']
        dob=request.GET['dob']
        salary=request.GET['salary']
        conn=sql.connect(host="localhost",port=3306,database='django_connectivity',user='root',passwd='123')
        cmd=conn.cursor()
        query="insert into employee(employeename,address,state,city,birthdate,salary) values('{0}','{1}','{2}','{3}','{4}',{5})".format((firstname+" "+lastname),address,state,city,dob,salary)
        
        cmd.execute(query)
        conn.commit()
        conn.close()

        return render(request,'EmployeeInterface.html',{'msg':'Record Submitted Successfully'})
    except Exception as e:
        print("Errrrrrr:",e)
        return render(request,'EmployeeInterface.html',{'msg':'Fail to  Submit Record'})
def DisplayAll_Employee(request):
    try:
           conn=sql.connect(host="localhost",port=3306,database='django_connectivity',user='root',passwd='123')
           cmd=conn.cursor()
           query="select * from employee"
           cmd.execute(query)
           records=cmd.fetchall()
           conn.close()

           return render(request,'DisplayAll.html',{'records':records})
    except Exception as e:
        print("Errrrrrr:",e)
        return render(request,'DisplayAll.html',{'msg':'Fail to  Fetch Record'})