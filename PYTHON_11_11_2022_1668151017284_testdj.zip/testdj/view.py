from django.shortcuts import render
def First_Action(request):
    return render(request,"welcome.html")

def Second_Action(request):
    return render(request,"profile.html",{'name':'Sandeep Sappal','city':'Gwalior','state':'Madhya Pradesh'})
    
def InterestInterface(request):
    return render(request,"simpleinterest.html")    
def calculate(request):
    amount=int(request.GET['amount'])
    rate=int(request.GET['rate'])
    time=int(request.GET['time'])
    iamt=amount*rate*time/100
    return render(request,"simpleinterest.html",{'iamt':iamt})    



